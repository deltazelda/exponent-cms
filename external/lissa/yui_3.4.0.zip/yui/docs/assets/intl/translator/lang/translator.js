YUI.add("lang/translator", function(Y) {

    Y.Intl.add(

        "translator",           // Associated Module 
        "",                     // Root

        {                       // Translated String Key/Value Pairs 
            hello:"Hello",   
            goodbye: "Goodbye"
        }

    );

}, "3.1.0");
