<?php
sleep(5);
header('Content-type: text/plain');
echo "TIMEOUT";
?>
