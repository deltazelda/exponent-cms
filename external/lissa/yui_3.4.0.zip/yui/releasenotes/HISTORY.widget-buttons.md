3.4.0PR3 - Initial release
--------------------------