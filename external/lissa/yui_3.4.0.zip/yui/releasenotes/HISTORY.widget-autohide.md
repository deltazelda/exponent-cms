3.4.0PR3
--------

  * Changed from a widget plugin to an extension

3.4.0PR2 - Initial release
--------------------------