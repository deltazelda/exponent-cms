JSONP Change History
====================

3.4.0
-----

  * Support added to specify charset or additional attributes to add to the
    script tag.
  * Success and failure callbacks are no longer executed if the request
    takes longer than the configured timeout

3.3.0
-----

  * allowCache config option added to use the same function proxy for
    generated requests.  Useful to benefit from YQL caching.

3.2.0
-----

Initial release
