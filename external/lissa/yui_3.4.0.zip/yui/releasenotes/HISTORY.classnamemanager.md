History
=======

3.4.0
-----

  * No change

3.3.0
-----

  * No change

3.2.0
-----

  * No change

3.1.1
-----

  * No change

3.1.0
-----

  * IMPORTANT: Changed default prefix to "yui3-" to avoid collisions with yui2 code,
    which uses "yui-". Bundled CSS has also been updated.

  * getClassName can now be invoked with a boolean skipPrefix argument set to true to
    avoid adding the default prefix when creating the class name.

  * Whitespace is no longer replaced in the generated class name.

3.0.0
-----

  * No change

3.0.0 beta 1
------------

  * Now uses Y.cached
  * All white space is stripped from incoming arguments

3.0.0 PR2
---------

* Initial 3.0 revision
