Widget Position Align
=====================

3.4.0PR3
--------

  * Added "alignOn" attribute which allows the implementer to specify when
  	the widget should be re-aligned. By default, it re-aligns on window resize
  	and scroll.


3.4.0PR2
--------

  * Widgets are kept in alignment when window is resized or scrolled.

3.3.0
-----

  * No changes

3.2.0
-----

  * No changes

3.1.1
-----

  * No changes

3.1.0
-----

  * Renamed module from widget-position-ext to widget-position-align

3.0.0
-----

  * No Changes

3.0.0 beta 1
------------

  * No Changes

3.0.0PR2 - Initial release
--------------------------

