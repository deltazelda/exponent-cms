Overlay
=======

3.4.0
-----

  * No changes, see Widget and extensions for changes to
    dependencies.

3.3.0
-----

  * No changes, see Widget and extensions for changes to
    dependencies.

3.2.0
-----

  * No changes, see Widget and extensions for changes to
    dependencies.

3.1.1
-----

  * No changes

3.1.0
-----

  * Added WidgetConstrain support to the packaged Overlay class.

  * Fixed centering when content is set in constructor.

3.0.0
-----

  * Modified progressive enhancement use case, to use document
    fragments instead of innerHTML to preserve event listeners.

  * Fixed use of centered, x and y in the constructor. These all
    needed 'lazyAdd' configuration since they had setters which 
    modified other attribute state.

3.0.0 beta 1
------------

  * No changes

3.0.0PR2 - Initial release
--------------------------
