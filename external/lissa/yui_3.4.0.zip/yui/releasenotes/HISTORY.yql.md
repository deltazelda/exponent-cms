YQL Change History
=================================

### 3.4.0
    
    #2530246 - Fixed bug in yql module where options ('opts') were not actually being used.  This prevented use YQL calls over SSL, which some tables require.

### 3.3.0

    #2529504 - Added support for JSONP allowCache setting to make YQL requests use the same callback

### 3.2.0

    Initial Release
