TabView Change History
======================

3.4.0
-----

  * Now accepts a Node instance for the Tab `content` attribute. [Ticket 2529830]


3.3.0
-----

  * No change.


3.2.0
-----

  * Bug fix: No longer requesting non-existent tabview-plugin.css. [Ticket 2529830]


3.1.1
-----

  * Bug fix: Allow for nested TabView widgets. [Ticket 2528737]
  * Bug fix: Removed default styling from core CSS. [Ticket 2528782]


3.1.0
-----

  * Initial release
