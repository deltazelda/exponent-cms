Rich Text Editor Change History
===============================

### 3.4.0

Third release of EditorBase. Considerable work was done on this component, but there are no
public tickets associated with the issues that were resolved. This version of EditorBase is the 
current version being used in the new Yahoo! Mail. It's production stable and ready to be used with
the proper skins and GUI.

### 3.3.0

Second release of EditorBase. Considerable work was done on this component, but there are no
public tickets associated with the issues that were resolved.

### 3.2.0

Initial Release

This release is a core utility release, the Editor instance that is created contains no GUI.
It's only the iframe rendering and event system.
