Widget Stack
============

3.4.0
-----

  * No changes

3.3.0
-----

  * No changes

3.2.0
-----

  * No changes

3.1.1
-----

  * No changes

3.1.0
-----

  * No changes

3.0.0
-----

  * Recreate iframe shim from TEMPLATE for each instance, instead of
    cloning a class level cached Node instance, so that ownerDocument
    can be set to match the bounding box.

3.0.0 beta 1
------------

  * No Changes

3.0.0PR2 - Initial release
--------------------------
