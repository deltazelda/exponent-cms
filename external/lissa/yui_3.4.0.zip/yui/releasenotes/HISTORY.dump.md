Dump Change History
===================

3.3.0
-----

  * No changes.

3.2.0
-----

  * No changes.

3.1.1
-----

  * No changes.

3.1.0
-----

  * No changes.

3.0.0
-----

  * Better handling of HTML elements.

3.0.0beta1
----------

  * Added `/regexp/` formatting.

3.0.0pr2
--------

  * No changes.

3.0.0pr1
--------

  * Initial release.
