MenuNav Change History
======================

3.4.0
-----

  * No changes.


3.3.0
-----

  * No changes.


3.2.0
-----

  * No changes.


3.1.2
-----

  * No changes.


3.1.1
-----

  * No changes.


3.1.0
-----

  * Fixed issue where moving the mouse from a submenu label directly out of the
    document to the browser chrome would trigger a JS error in IE.

  * Fixed issue where submenus would not appear if the user landed on a submenu
    label by moving the mouse diagonally from the parent menu.

3.0.0
-----

  * No changes.


3.0.0 beta 1
------------

  * Now lives on the `Plugin` namespace, as opposed to the `plugin` namespace.
  * Now requires the Focus Manager Node Plugin (`Y.Plugin.NodeFocusManager`).
  * Now extends `Y.Base`.


3.0.0pr2
--------

  * Initial release.
