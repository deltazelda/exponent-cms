YUI Throttle Change History
===========================


## 3.4.0

Removed from yui-core and bumped to a stand alone module.
