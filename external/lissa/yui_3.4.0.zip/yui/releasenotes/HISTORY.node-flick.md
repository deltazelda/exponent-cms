Flick Node Plugin
=================

3.4.0
-----

   * No changes.

3.3.0
-----

   * No changes.

3.2.0
-----

   * New beta component
