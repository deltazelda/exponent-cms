Highlight Change History
========================

3.4.0
-----

  * Fixed a bug that resulted in invalid escaped HTML when running a highlighter
    with an empty needle. [Ticket #2529945]
  * Fixed an off-by-one bug in which an unhighlighted single char at the end of
    a highlighted string would be discarded when using `allFold()`. [Ticket
    #2530529]

3.3.0
-----

  * Initial release.
