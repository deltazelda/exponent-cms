Sortable Utility Change History
===============================

### 3.4.0

No changes

### 3.3.0

   * #2529220 Sortable does not allow dragging from original container to a different container back to original i...

### 3.2.0

   * #2529063 Sortable: add getOrdering method
   * #2528754 Sortable with nested lists
   * #2528761 Request for Sortables to provide events from->to
   * #2528769 Scroll Sortables
   * #2528819 Sortable allows child div to move outside parent div
   * #2529061 Sortable.destroy removes node


### 3.1.1

No changes

### 3.1.0

Initial Release
